package semester1.practice10;

public class Main {
    public static void main(String[] args) {
        System.out.println("ДОМАШНЄ ЗАВДАННЯ 1 ");
        dz1.main(args);

        System.out.println("\nДОМАШНЄ ЗАВДАННЯ 2");
        dz2.main(args);

        System.out.println("\n ДОМАШНЄ ЗАВДАННЯ 3");
        dz3.main(args);

        System.out.println("\n ПРАКТИЧНА РОБОТА 10 ");
        pz10.main(args);
    }
}
